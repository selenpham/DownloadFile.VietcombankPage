package Vietcombank;

import java.io.IOException;
import java.sql.Driver;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.ContextClickAction;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.Hooks;
import net.bytebuddy.asm.Advice.Enter;
import pageObjects.ShopMainPage;
import pageObjects.VietcomMainPage;

@Listeners(resources.Listeners.class)
public class T01_downloadexcel extends Hooks{
	
	public T01_downloadexcel() throws IOException {
		super();
	}

	@Test
	public void tc01_download_rate() throws IOException, InterruptedException {
		VietcomMainPage main = new VietcomMainPage();
		Thread.sleep(5000);
//Số iframe trong trang
		
		int sizeIFrame = getDriver().findElements(By.tagName("iframe")).size();
		System.out.println("number of iframe : "+sizeIFrame);
//Đóng cửa sổ nhỏ
		
		Actions act =new Actions(getDriver());
		act.moveToElement(main.clickDesau()).click().build().perform();
		Thread.sleep(2000);
//Đóng iframe

		act.moveToElement(getDriver().findElement(By.xpath("//*[@id='fb-root']/div[3]/div/iframe[1]"))).click().build().perform();
		Thread.sleep(2000);
//Di chuyển đến ô ngày tháng. nhấn nút download

		act.moveToElement(getDriver().findElement(By.xpath("//*[@id='txttungay']"))).click();
		main.clickDownExcel().click();
		Thread.sleep(2000);
		System.out.println("Dowload file ti gia thanh cong");;
		Thread.sleep(2000);
//Số iframe trong trang
	
		act.moveToElement(getDriver().findElement(By.xpath("//*[@id='fb-root']/div[3]/div/iframe[1]"))).click().build().perform();

//Xóa date hiện hành, nhập date cũ cần xem
		main.clickChoseDate().clear();
		main.clickChoseDate().sendKeys("22/5/2023");
		main.clickChoseDate().click();
		Thread.sleep(2000);
		act.moveToElement(getDriver().findElement(By.xpath("//*[@id='fb-root']/div[3]/div/iframe[1]"))).click().build().perform();
	    act.keyDown(Keys.CONTROL).sendKeys(Keys.END).build().perform();
	    
		Thread.sleep(2000);
// Di chuyển thanh scroll xuống cuối page và lên đầu home
	    act.keyDown(Keys.CONTROL).sendKeys(Keys.HOME).build().perform();
		Thread.sleep(2000);
	}
  
}
