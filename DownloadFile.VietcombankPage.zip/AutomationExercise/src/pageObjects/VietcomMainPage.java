package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import base.BasePage;

public class VietcomMainPage extends BasePage{


	public WebDriver driver;
	
	
	By inputSearch = By.xpath("//*[@id='kwdtop']");
	By searchIcon = By.cssSelector(".btn-search [aria-hidden]");
	
	By downExcel = By.xpath("//*[@id='btnExcel']");
	By choseDate = By.xpath("//*[@id='txttungay']");

	By mesgClose = By.cssSelector("._9q4i [width]");
	
	By desau = By.xpath("//*[@id='de-sau']");
	
	public VietcomMainPage() throws IOException {
		super();
	}
			
	public WebElement fillInputSearch() throws IOException {
		this.driver = getDriver();
		return driver.findElement(inputSearch);
	}
	
	public WebElement clickSearchIcon() throws IOException {
		this.driver = getDriver();
		return driver.findElement(searchIcon);
	}
	
	public WebElement clickMesgClose() throws IOException {
		this.driver = getDriver();
		return driver.findElement(mesgClose);
	}

	 public WebElement clickDownExcel() throws IOException {
			this.driver = getDriver();
			return driver.findElement(downExcel);
		}
	 
	 public WebElement clickChoseDate() throws IOException {
			this.driver = getDriver();
			return driver.findElement(choseDate);
		}
	
	 public WebElement clickDesau() throws IOException {
			this.driver = getDriver();
			return driver.findElement(desau);
		}
	
}
